// import { Container } from './styles';

function Home() {
    return (
        <div>
            Vitrine
        </div>
    )
}

export default Home;