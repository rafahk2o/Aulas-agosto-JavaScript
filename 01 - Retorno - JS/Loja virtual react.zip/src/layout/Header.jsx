function Header(){
    return(
        <header>
           
    <div class="topo">
        <div class="topo-text">
            <h1>Loja virtual Senac</h1>
        </div>

    </div>
    <div id="produto-lista">
       
    </div>
    </header>
        
    )
}

export default Header;