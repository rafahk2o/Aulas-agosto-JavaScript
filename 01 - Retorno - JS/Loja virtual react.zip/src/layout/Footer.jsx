function Footer() {
  return(
      <footer>
          Todos os direitos reservados
      </footer>
  )
}

export default Footer;