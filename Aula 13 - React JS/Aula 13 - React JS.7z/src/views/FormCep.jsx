import FormularioCep from '../components/FormularioCep';



export default class FormCep extends Component {
    render() {
        return (
            <div>
                <h2>Endereço de entrega</h2>
                <FormularioCep />

            </div>
        )
    }
}