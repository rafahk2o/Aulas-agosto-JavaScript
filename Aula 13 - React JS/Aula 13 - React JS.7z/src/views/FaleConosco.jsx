import { Component } from 'react';
import FormContato from '../components/FormContato';

export default class FaleConosco extends Component {
    render() {
        return (
            <div>
                <h2>Fale Conosco</h2>
                <FormContato />

            </div>
        )
    }
}