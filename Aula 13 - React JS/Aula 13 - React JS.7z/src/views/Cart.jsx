

import Carrinho from '../components/Carrinho'; 
export default function Cart() {
    return (
        <div>
            <h1>Carrinho</h1> 
            <Carrinho />
        </div>
    )
} 