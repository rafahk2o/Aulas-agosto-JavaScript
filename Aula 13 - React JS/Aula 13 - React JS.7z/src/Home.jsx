// import { Container } from './styles';
import Vitrine from "./components/Vitrine";

function Home() {
    return (
        <div>
           <h1>Vitrine</h1> 
            <Vitrine />
        </div>
    )
}

export default Home;